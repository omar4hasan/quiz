<template>

	<div>sfsdfds</div>

</template>
<script>
export default {
	data () {
		return {
			
		}
	},
	mounted () {
		

	}
}
</script>