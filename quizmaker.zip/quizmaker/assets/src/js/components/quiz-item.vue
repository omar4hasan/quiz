<template>
	<div class="qm-question single">
		
		Single question

	</div>
</template>
<script>
export default {
	data: function(){

		return {
			answers: [],
			loading: false
		};
	},
	mounted: function(){


	},
	methods: {
		
		
	}
}
</script>