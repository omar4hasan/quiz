<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

?>								</td>
							</tr>
						</tbody>
					</table>
				</div>
			</td>
		</tr>
		<tr>
			<td align="center" valign="top">
				<!-- Footer -->
				<table border="0" cellpadding="0" cellspacing="0" width="600" id="template_footer">
					<tr>
						<td style="margin-top:0;margin-bottom:0;margin-right:0;margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;font-size:13px;color:#CFCFCF;font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;">
							<p style="text-align: center;padding-top:24px;"><?php echo $email_footer; ?></p>
						</td>
					</tr>
				</table>
				<!-- End Footer -->
			</td>
		</tr>
	</tbody>
</table>
</body></html>