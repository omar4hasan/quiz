<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<p style="margin-top:0;margin-right:0;margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;margin-bottom:10px;font-weight:normal;font-size:14px;line-height:1.6;color:'#000000';">Hi, [{user_nicename}]!</p>
<p style="margin-top:0;margin-right:0;margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;margin-bottom:10px;font-weight:normal;font-size:14px;line-height:1.6;color:'#000000';">
	This is your result:
</p>
<p style="margin-top:0;margin-right:0;margin-left:0;padding-top:0;padding-bottom:0;padding-right:0;padding-left:0;font-family:'Helvetica Neue', 'Helvetica', Helvetica, Arial, sans-serif;margin-bottom:10px;font-weight:normal;font-size:14px;line-height:1.6;color:'#000000';">
	<ul>
		<li><strong>Score</strong> : [{score}] / [{total_score}]</li>
		<li><strong>Duration</strong> : [{duration}]</li>
		<li><strong>Date</strong> : [{date}]</li>
		<li><strong>Certificate ID</strong> : [{user_cert_id}]</li>
	</ul>
</p>