
	
result : <?php echo $total_points; ?>

