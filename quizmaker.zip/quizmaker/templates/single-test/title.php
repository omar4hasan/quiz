<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<h1 class="title"><?php the_title(); ?></h1>