<?php 
if ( ! defined( 'ABSPATH' ) ) { exit; }

$settings	=	isset($doing_data['settings']) && $doing_data['settings'] ? $doing_data['settings'] : array();

?>

<div class="doing-body">

	<div class="banner-hero">
		
	</div>

	

	<h1 class="title-hero"><?php the_title(); ?></h1>