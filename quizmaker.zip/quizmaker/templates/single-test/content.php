<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>

<div class="description">
<?php the_content(); ?>
</div>