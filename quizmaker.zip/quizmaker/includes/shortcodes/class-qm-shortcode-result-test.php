<?php

if ( ! defined( 'ABSPATH' ) ) { exit; }

class QM_Shortcode_Result_Test {
	
	public static function output(){
		
		qm_get_template('single-test/start.php');
	}
}