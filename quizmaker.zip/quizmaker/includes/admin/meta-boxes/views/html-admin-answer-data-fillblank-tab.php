<div class="answer-type-panel" id="answer-type-fill_blank">
		
<?php if($answers && $answer_type == 'fill_blank'): ?>

	<textarea name="anwsers_fill_blank" class="qm-s-wide"><?php echo $answers; ?></textarea>

<?php else: ?>

	<textarea name="anwsers_fill_blank" class="qm-s-wide"></textarea>

<?php endif; ?>
		
</div>