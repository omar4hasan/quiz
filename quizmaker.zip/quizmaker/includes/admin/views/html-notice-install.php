<?php
/**
 * Admin View: Notice - Install
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div id="message" class="updated quizmaker-message qm-connect">
	<p><?php _e( '<strong>Welcome to Quizmaker</strong> &#8211; You&lsquo;re almost ready to start making tests :)', 'quizmaker' ); ?></p>
</div>
