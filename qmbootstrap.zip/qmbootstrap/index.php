<?php
/**
 * The main template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); ?>

<?php dynamic_sidebar('home-introduction'); ?>

<?php if(is_active_sidebar('home-sidebar')): ?>

<div class="container">
	<div class="row">

		<div class="col-md-3">

			<?php dynamic_sidebar('home-sidebar'); ?>
			
		</div>

		<div class="col-md-9">
			
			<?php dynamic_sidebar('home-container'); ?>

		</div>

	</div>
</div>

<?php else: ?>

<div class="container">
	<?php dynamic_sidebar('home-container'); ?>
</div>

<?php endif; ?>



<?php get_footer(); ?>