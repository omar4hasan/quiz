<?php
/**
 * The template for displaying the header
 *
 * Displays all of the head element and everything up until the "site-content" div.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?><!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js">
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width">
	<link rel="profile" href="http://gmpg.org/xfn/11">
	<link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
	<!--[if lt IE 9]>
	<script src="<?php echo esc_url( get_template_directory_uri() ); ?>/js/html5.js"></script>
	<![endif]-->
	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>

	<div id="qmbootstrap-wrapper">

		<header class="navbar navbar-expand-md bd-navbar main-header">

			<div class="container">
				<a class="navbar-brand" href="<?php echo site_url(); ?>">

					<?php if( get_theme_mod( 'custom_logo' )): ?>
					<?php the_custom_logo(); ?>
					<?php else: ?>
					<img src="http://demo.awstheme.com/live/wordpress/quizmaker/wp-content/uploads/2016/07/cropped-logo_text-192x192.png" width="auto" height="30" alt="">
					<?php endif; ?>
				</a>

				<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo02" aria-controls="navbarTogglerDemo02" aria-expanded="true" aria-label="Toggle navigation">
				    <span class="navbar-toggler-icon"><i class="material-icons">menu</i></span>
				</button>

				<div class="collapse navbar-collapse" id="navbarTogglerDemo02">

					<?php
					    wp_nav_menu(
						    array(
							    'theme_location'	=> 'primary',
							    'container_class'		=> 'mr-auto mt-lg-0',
							    'menu_class'		=> 'navbar-nav ',
						    )
					    );
				    ?>

			  	</div>

			</div>

		</header>
