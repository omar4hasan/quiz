<?php
/**
 * The default template for displaying content
 *
 * Used for both single and index/archive/search.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */
?>

<div class="container">

	<article id="post-<?php the_ID(); ?>" <?php post_class('mt-4'); ?>>
		<?php
			// Post thumbnail.
			qmbootstrap_post_thumbnail();
		?>

		<header class="mt-4 text-center entry-header">
			<?php
				if ( is_single() ) :
					the_title( '<h1 class="entry-title">', '</h1>' );
				else :
					the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
				endif;
			?>
		</header><!-- .entry-header -->

		<div class="mt-4 entry-content">
			<?php
				/* translators: %s: Name of current post */
				the_content();

			?>
		</div><!-- .entry-content -->

	</article><!-- #post-## -->

</div>
