import Vue from 'vue';


Window.Vue = Vue;

Vue.config.debug = true;
Vue.config.silent = false;
Vue.config.devtools = true;

jQuery(document).ready(function() {

	if( jQuery('#section-features').length > 0 ) {

		new Vue({
			el: '#section-features',
			components: {
				
			},
			data: {
				currentFeature: 1
			},
			methods: {
				showFeature: function(){

					console.log('show features');
				}
			}
		});

	}

});