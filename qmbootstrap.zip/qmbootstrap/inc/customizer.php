<?php

function qmbootstrap_customize_register( $wp_customize ) {
  	
	$wp_customize->add_setting( 'quizmaker_desktop_logo' );
	
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'quizmaker_desktop_logo', array(
           'label'    => __( 'Upload Logo' ),
           'section'  => 'title_tagline',
           'settings' => 'quizmaker_desktop_logo'
       ) ) );
		   
}
add_action( 'customize_register', 'qmbootstrap_customize_register' );