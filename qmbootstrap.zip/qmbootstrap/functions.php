<?php 


if ( ! function_exists( 'qmbootstrap_setup' ) ) :
/**
 * Sets up theme defaults and registers support for various WordPress features.
 *
 * Note that this function is hooked into the after_setup_theme hook, which
 * runs before the init hook. The init hook is too late for some features, such
 * as indicating support for post thumbnails.
 *
 * @since Twenty Fifteen 1.0
 */
function qmbootstrap_setup() {

	/*
	 * Make theme available for translation.
	 * Translations can be filed at WordPress.org. See: https://translate.wordpress.org/projects/wp-themes/twentyfifteen
	 * If you're building a theme based on twentyfifteen, use a find and replace
	 * to change 'twentyfifteen' to the name of your theme in all the template files
	 */
	load_theme_textdomain( 'qmbootstrap' );

	// Add default posts and comments RSS feed links to head.
	add_theme_support( 'automatic-feed-links' );

	/*
	 * Let WordPress manage the document title.
	 * By adding theme support, we declare that this theme does not use a
	 * hard-coded <title> tag in the document head, and expect WordPress to
	 * provide it for us.
	 */
	add_theme_support( 'title-tag' );

	/*
	 * Enable support for Post Thumbnails on posts and pages.
	 *
	 * See: https://codex.wordpress.org/Function_Reference/add_theme_support#Post_Thumbnails
	 */
	add_theme_support( 'post-thumbnails' );
	set_post_thumbnail_size( 825, 510, true );

	// This theme uses wp_nav_menu() in two locations.
	register_nav_menus( array(
		'primary' => __( 'Primary Menu',      'qmbootstrap' ),
		'footer' => __( 'Footer Menu',      'qmbootstrap' ),
		'social'  => __( 'Social Links Menu', 'qmbootstrap' ),
	) );

	/*
	 * Switch default core markup for search form, comment form, and comments
	 * to output valid HTML5.
	 */
	add_theme_support( 'html5', array(
		'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
	) );

	/*
	 * Enable support for Post Formats.
	 *
	 * See: https://codex.wordpress.org/Post_Formats
	 */
	add_theme_support( 'post-formats', array(
		'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
	) );

	/*
	 * Enable support for custom logo.
	 *
	 * @since Twenty Fifteen 1.5
	 */
	add_theme_support( 'custom-logo', array(
		'height'      => 30,
		'width'       => 30,
		'flex-height' => true,
	) );
	
	// Indicate widget sidebars can use selective refresh in the Customizer.
	add_theme_support( 'customize-selective-refresh-widgets' );
}
endif; // twentyfifteen_setup
add_action( 'after_setup_theme', 'qmbootstrap_setup' );

/**
 * Register widget area.
 *
 * @since Twenty Fifteen 1.0
 *
 * @link https://codex.wordpress.org/Function_Reference/register_sidebar
 */
function qmbootstrap_widgets_init() {

	register_sidebar( array(
		'name'          => __( 'Widget Area', 'qmbootstrap' ),
		'id'            => 'sidebar-1',
		'description'   => __( 'Add widgets here to appear in your sidebar.', 'qmbootstrap' ),
		'before_widget' => '<div id="%1$s" class="box-sidebar %2$s">',
		'after_widget'  => '</div>'
	) );

	register_sidebar( array(
	    'id'          => 'home-container',
	    'name'        => __( 'Home Container', 'qmbootstrap' ),
		'before_widget' => '<div id="%1$s" class="qm-home-container-widget %2$s">',
		'after_widget'  => '</div>'
	) );

	register_sidebar( array(
	    'id'          => 'home-sidebar',
	    'name'        => __( 'Home Sidebar', 'qmbootstrap' ),
		'before_widget' => '<div id="%1$s" class="box-sidebar qm-home-sidebar-widget %2$s">',
		'after_widget'  => '</div>'
	) );

	register_sidebar( array(
	    'id'          => 'home-introduction',
	    'name'        => __( 'Home Introduction', 'qmbootstrap' ),
		'before_widget' => '<div id="%1$s" class="qm-home-introduction-widget %2$s">',
		'after_widget'  => '</div>'
	) );
	
}
add_action( 'widgets_init', 'qmbootstrap_widgets_init' );

/**
 * Enqueue scripts and styles.
 *
 * @since Twenty Fifteen 1.0
 */
function qmbootstrap_scripts() {
	// Add custom fonts, used in the main stylesheet.
	// wp_enqueue_style( 'twentyfifteen-fonts', twentyfifteen_fonts_url(), array(), null );

	// Add Genericons, used in the main stylesheet.
	// wp_enqueue_style( 'genericons', get_template_directory_uri() . '/genericons/genericons.css', array(), '3.2' );

	// wp_enqueue_style( 'material-icons', 'https://fonts.googleapis.com/icon?family=Material+Icons' );

	// wp_enqueue_style('quizmaker-bootstrap-library', QUIZMAKER_URI . 'assets/vendor/bootstrap/css/bootstrap.min.css', array(), '4.0.2');

	// Load our main stylesheet.
	wp_enqueue_style( 'qmbootstrap-style', get_stylesheet_uri() . '?v=1.0.0' );

	// Load the Internet Explorer specific stylesheet.
	// wp_enqueue_style( 'twentyfifteen-ie', get_template_directory_uri() . '/css/ie.css', array( 'twentyfifteen-style' ), '20141010' );
	// wp_style_add_data( 'twentyfifteen-ie', 'conditional', 'lt IE 9' );

	// Load the Internet Explorer 7 specific stylesheet.
	// wp_enqueue_style( 'twentyfifteen-ie7', get_template_directory_uri() . '/css/ie7.css', array( 'twentyfifteen-style' ), '20141010' );
	// wp_style_add_data( 'twentyfifteen-ie7', 'conditional', 'lt IE 8' );

	// wp_enqueue_script( 'twentyfifteen-skip-link-focus-fix', get_template_directory_uri() . '/js/skip-link-focus-fix.js', array(), '20141010', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}

	

	// wp_enqueue_script( 'qmbootstrap-jquery-slim', get_template_directory_uri() . '/vendor/jquery-3.2.1.slim.min', array( 'jquery' ), '20141012', true);

	// wp_enqueue_script( 'qmbootstrap-popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js', array( 'jquery' ), '20141011', true);

	// wp_enqueue_script( 'qmbootstrap-bootstrap4', get_template_directory_uri() . '/vendor/bootstrap/dist/js/bootstrap.min.js', array( 'jquery' ), '20141010', true);

	// wp_enqueue_script( 'qmbootstrap-script', get_template_directory_uri() . '/assets/js/qmbootstrap.min.js', array( 'jquery' ), '20150309', true );

	// if ( is_singular() && wp_attachment_is_image() ) {
	// 	wp_enqueue_script( 'twentyfifteen-keyboard-image-navigation', get_template_directory_uri() . '/js/keyboard-image-navigation.js', array( 'jquery' ), '20141010' );
	// }

	// wp_enqueue_script( 'twentyfifteen-script', get_template_directory_uri() . '/js/functions.js', array( 'jquery' ), '20150330', true );
	// wp_localize_script( 'twentyfifteen-script', 'screenReaderText', array(
	// 	'expand'   => '<span class="screen-reader-text">' . __( 'expand child menu', 'twentyfifteen' ) . '</span>',
	// 	'collapse' => '<span class="screen-reader-text">' . __( 'collapse child menu', 'twentyfifteen' ) . '</span>',
	// ) );
}
add_action( 'wp_enqueue_scripts', 'qmbootstrap_scripts' );

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';