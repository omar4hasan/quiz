<?php
/**
 * The template for displaying pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages and that
 * other "pages" on your WordPress site will use a different template.
 *
 * @package WordPress
 * @subpackage Twenty_Fifteen
 * @since Twenty Fifteen 1.0
 */

get_header(); 

$posts = get_posts([
	'category' => 19,
	'posts_per_page' => -1
]);

?>

	<div class="pt-4 pb-4 mb-4 page-header-wrapper">

		<div class="container">

			<h3 class="page-title mb-0"><?php echo get_the_title(get_the_ID()); ?></h3>

		</div>

	</div>

	<div class="mt-4 container">

		<div class="row">

			<div class="col-sm-12">

				<?php if( $posts ): ?>
					<?php foreach ($posts as $p): ?>
						
					
					<div class="media mb-4">
						<a href="<?php echo get_the_permalink($p->ID); ?>">
							<?php echo get_the_post_thumbnail($p->ID, 'post-thumbnail', ['class' => 'align-self-start mr-3', 'style' => 'width: 200px; height: auto;']); ?>
						</a>
						<div class="media-body">
						<h5 class="mt-0"><a href="<?php echo get_the_permalink($p->ID); ?>"><?php echo $p->post_title; ?></a></h5>

						
						<?php echo has_excerpt( $p ) ? get_the_excerpt($p->ID) : ''; ?>
						</div>
					</div>

					<?php endforeach ?>
				<?php endif; ?>

			</div>

		</div>

	</div>


<?php get_footer(); ?>
