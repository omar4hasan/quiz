
var gulp 		=	require('gulp'),
	path		=	require('path'),
	watch		=	require('gulp-watch'),
	concat		=	require('gulp-concat'),
	rename		=	require('gulp-rename'),
	less		=	require('gulp-less'),
	sass		=	require('gulp-sass'),
	uglify		=	require('gulp-uglify'),
	clean		=	require('gulp-clean'),
	cleanCSS	=	require('gulp-clean-css');

var checktextdomain =	require('gulp-checktextdomain');

var wpPot 		= require('gulp-wp-pot'),
	sort 		= require('gulp-sort');

gulp.task('clean_css', function(){
	return gulp.src('assets/css/*.css')
});

gulp.task('sass', function () {
  return gulp.src('assets/src/sass/qmbootstrap.scss')
    .pipe(sass.sync().on('error', sass.logError))
    .pipe(gulp.dest('assets/css'));
});

gulp.task('default', function(){

	watch('assets/src/sass/qmbootstrap.scss', { ignoreInitial: false }, function(){
		
		gulp.watch('assets/src/sass/qmbootstrap.scss', ['sass']);

	});
});