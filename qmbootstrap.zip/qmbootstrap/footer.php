<?php wp_footer(); ?>
	<footer id="main-footer">
		<div class="container">
			<div class="row">
				
				<div class="col-sm-6">
					
					<?php
					if ( has_nav_menu( 'social' ) ) {
					    wp_nav_menu(
						    array(
							    'theme_location'	=> 'social'
						    )
					    );

					}
				    ?>

				</div>

				<div class="col-sm-6">

					<?php
					if ( has_nav_menu( 'footer' ) ) {
					    wp_nav_menu(
						    array(
							    'theme_location'	=> 'footer',
							    'container_class'		=> 'wrap-footer-menu',
						    )
					    );

					}
				    ?>
					

				</div>

			</div>
		</div>
	</footer>
	</div>

	
</body>
</html>
